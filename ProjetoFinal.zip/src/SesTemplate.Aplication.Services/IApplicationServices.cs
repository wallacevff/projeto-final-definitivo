﻿namespace SesTemplate.Aplication.Services;

public interface IApplicationServices
{
}