﻿using AutoMapper;

namespace SesTemplate.Aplication.Services.AutoMapperProfiles;

public class AutoMapperProfileCadastroDto : Profile
{
    public AutoMapperProfileCadastroDto()
    {
        
    }
}
