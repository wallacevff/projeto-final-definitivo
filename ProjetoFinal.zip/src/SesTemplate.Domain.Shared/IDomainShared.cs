﻿namespace SesTemplate.Domain.Shared;

public interface IDomainShared
{
}