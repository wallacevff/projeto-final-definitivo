﻿namespace SesTemplate.Domain;

public interface IDomain
{
}