﻿namespace SesTemplate.Infra.Data;

public interface IInfraData
{
}