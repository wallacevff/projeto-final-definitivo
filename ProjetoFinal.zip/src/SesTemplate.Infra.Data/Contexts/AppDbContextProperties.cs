﻿namespace SesTemplate.Infra.Data.Contexts;

public partial class AppDbContext
{
  
}