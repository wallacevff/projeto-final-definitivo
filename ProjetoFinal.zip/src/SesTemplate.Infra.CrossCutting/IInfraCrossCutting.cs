﻿namespace SesTemplate.Infra.CrossCutting;

public interface IInfraCrossCutting
{

}
