﻿namespace SesTemplate.Application.Contracts;

public interface IApplicationContracts
{
}